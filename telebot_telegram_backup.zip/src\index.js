import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { Connection, PublicKey } from '@solana/web3.js';
import { Telegraf } from 'telegraf';
import WebSocket from 'ws';
import { z } from 'zod';
import {
  addChannelToCoin,
  addChannelToCoinByContract,
  getCoin,
  getCoinByContract,
  getCoinsByChat,
  getPrimaryCoin,
  getTrackedChats,
  getTrendingCoins,
  replaceStore,
  readStore,
  recordBuyEvent,
  upsertCoin
} from './store.js';
import { renderBuyAlert, renderCoinList, renderTrendingList } from './render.js';

const {
  BOT_TOKEN,
  PORT = 3000,
  WEBHOOK_SECRET,
  HELIUS_AUTH_HEADER,
  HELIUS_API_KEY,
  HELIUS_WEBHOOK_ID,
  DEBUG_HELIUS_CHAT_ID,
  DEBUG_HELIUS_NOTIFICATIONS = 'false',
  ENABLE_HELIUS_POLLING = 'false',
  HELIUS_POLL_INTERVAL_MS = 15000,
  ENABLE_BITQUERY_STREAM = 'false',
  BITQUERY_TOKEN,
  ENABLE_PUMPPORTAL_STREAM = 'false',
  PUMPPORTAL_API_KEY,
  ENABLE_NATIVE_SOLANA_WATCHER = 'false',
  ENABLE_DEXSCREENER_POLLING = 'false',
  DEXSCREENER_POLL_INTERVAL_MS = 20000,
  ENABLE_KEEP_ALIVE = 'false',
  KEEP_ALIVE_URL,
  KEEP_ALIVE_INTERVAL_MS = 600000,
  TELEGRAM_BACKUP_CHAT_ID,
  SOLANA_WS_URL,
  TELEGRAM_WEBHOOK_URL,
  BASE_URL,
  ALERT_CHAT_ID,
  SOLANA_RPC_HTTP = 'https://api.mainnet-beta.solana.com',
  DEFAULT_QUOTE_SYMBOL = 'SOL',
  TRENDING_LIMIT = 5
} = process.env;

if (!BOT_TOKEN) {
  throw new Error('BOT_TOKEN is required. Copy .env.example to .env and add your Telegram bot token.');
}

const bot = new Telegraf(BOT_TOKEN);
const app = express();
const telegramWebhookPath = `/telegram/${BOT_TOKEN}`;
const telegramWebhookUrl = TELEGRAM_WEBHOOK_URL ?? (BASE_URL ? `${BASE_URL.replace(/\/$/, '')}${telegramWebhookPath}` : null);
let botUsername = '';
let bitquerySocket = null;
let bitqueryRestartTimer = null;
let pumpPortalSocket = null;
let pumpPortalRestartTimer = null;
let nativeSolanaConnection = null;
let nativeSolanaSubscriptionIds = [];
let telegramBackupChatId = TELEGRAM_BACKUP_CHAT_ID || '';
const nativeSolanaSeenSignatures = new Set();
const dexScreenerState = new Map();
const PUMP_PROGRAM_ID = new PublicKey('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P');

app.use(bot.webhookCallback(telegramWebhookPath));
app.use(express.json({ limit: '1mb' }));

const buyEventSchema = z.object({
  symbol: z.string().min(1).optional(),
  contract: z.string().min(1).optional(),
  buyer: z.string().optional(),
  tokenAmount: z.coerce.number().nonnegative(),
  usdValue: z.coerce.number().nonnegative().default(0),
  quoteAmount: z.coerce.number().nonnegative().optional(),
  quoteSymbol: z.string().optional(),
  marketCap: z.coerce.number().nonnegative().optional(),
  dex: z.string().optional(),
  txUrl: z.string().url().optional()
}).refine((event) => event.symbol || event.contract, {
  message: 'Either symbol or contract is required.'
});

bot.start(showHelp);
bot.help(showHelp);

async function showHelp(ctx) {
  return ctx.reply([
    'Buy bot is online.',
    '',
    'Commands:',
    '/help - show this menu',
    '/coins - list tracked coins',
    '/trending - show 24h trending volume',
    '/chatid - show this Telegram chat id',
    '/chats - show tracked chats',
    '/backup_here - use this chat/channel for backups',
    '/backup_now - post a backup to the backup chat',
    '/restore_backup - reply to a backup message to restore',
    '/track OGRE - add this chat/channel to a coin',
    '/setcoin SYMBOL CONTRACT - register this chat for a coin',
    '/setca SYMBOL CONTRACT - same as /setcoin',
    '/testbuy OGRE - send a test buy alert',
    '/addcoin SYMBOL Name | chain | contract | buyUrl - register a coin',
    '',
    'Real buys come from the /api/buy webhook. Connect that to Helius, Moralis, Bitquery, or another Solana/Pump.fun listener.'
  ].join('\n'));
}

bot.command('coins', async (ctx) => {
  const store = await readStore();
  await ctx.reply(renderCoinList(store.coins), { disable_web_page_preview: true });
});

bot.command('trending', async (ctx) => {
  const primaryCoin = await getPrimaryCoin();
  const trending = await getTrendingCoins(Number(TRENDING_LIMIT));
  await ctx.reply(renderTrendingList(trending, primaryCoin), { disable_web_page_preview: true });
});

bot.command('chatid', async (ctx) => {
  await ctx.reply(`This chat id is: ${ctx.chat.id}`);
});

bot.command('chats', async (ctx) => {
  const chatCoins = await getCoinsByChat(ctx.chat.id);
  if (chatCoins.length === 0) {
    await ctx.reply('This chat is not tracking any coins yet. Use /setcoin SYMBOL CONTRACT.');
    return;
  }

  await ctx.reply(chatCoins.map((coin) => `$${coin.symbol} -> ${coin.contract}`).join('\n'));
});

bot.command('sync_helius', async (ctx) => {
  const store = await readStore();
  const contracts = store.coins
    .filter((coin) => coin.enabled && coin.contract)
    .map((coin) => coin.contract);

  const heliusResult = await ensureHeliusTracksContracts(contracts);
  await ctx.reply(renderHeliusSyncStatus(heliusResult) || 'Helius sync did not run. Check env vars.');
});

bot.command('backup_here', async (ctx) => {
  telegramBackupChatId = String(ctx.chat.id);
  await sendTelegramBackup('Backup channel set from /backup_here.');
  await ctx.reply('This chat is now the Telegram backup channel. Backups will post here after setup changes.');
});

bot.command('backup_now', async (ctx) => {
  if (!telegramBackupChatId) telegramBackupChatId = String(ctx.chat.id);
  await sendTelegramBackup('Manual backup from /backup_now.');
  await ctx.reply('Backup posted.');
});

bot.command('restore_backup', async (ctx) => {
  const restored = await restoreTelegramBackupFromReply(ctx);
  if (restored) {
    await ctx.reply(`Restored backup: ${restored.coins.length} coins, ${restored.events.length} events.`);
    restartBitqueryStreamSoon();
    restartPumpPortalStreamSoon();
    restartNativeSolanaWatcherSoon();
  }
});

bot.command('scan_now', async (ctx) => {
  const result = await pollTrackedContractsOnce();
  await ctx.reply([
    'Manual chain scan finished.',
    `Scanned contracts: ${result.scannedContracts}`,
    `Accepted buys: ${result.accepted}`,
    `Ignored transactions: ${result.ignored}`
  ].join('\n'));
});

bot.on('my_chat_member', async (ctx) => {
  const update = ctx.update.my_chat_member;
  const chat = update.chat;
  const status = update.new_chat_member.status;

  if (['member', 'administrator'].includes(status)) {
    console.log(`Bot was added to chat ${chat.id} (${chat.title ?? chat.username ?? chat.type}). Use /setcoin SYMBOL CONTRACT in that chat to enable buy alerts.`);
  }
});

bot.command('track', async (ctx) => {
  const symbol = getUpdateText(ctx).split(/\s+/)[1];
  if (!symbol) {
    await ctx.reply('Usage: /track OGRE');
    return;
  }

  try {
    const coin = await addChannelToCoin(symbol, ctx.chat.id);
    const heliusResult = await ensureHeliusTracksContract(coin.contract);
    await ctx.reply([
      `This chat is now tracking $${coin.symbol}. Make sure the bot is admin if this is a channel.`,
      renderHeliusSyncStatus(heliusResult)
    ].filter(Boolean).join('\n'));
    await sendTelegramBackup(`Tracked $${coin.symbol} in chat ${ctx.chat.id}.`);
  } catch (error) {
    await ctx.reply(error.message);
  }
});

bot.command(['setcoin', 'setca'], async (ctx) => {
  const text = getUpdateText(ctx);
  const [, symbol, contract, ...rest] = text.split(/\s+/);

  if (!symbol || !contract) {
    await ctx.reply('Usage: /setcoin SYMBOL CONTRACT');
    return;
  }

  const buyUrl = rest[0] || `https://pump.fun/coin/${contract}`;
  const coin = await addChannelToCoinByContract(contract, ctx.chat.id, {
    symbol,
    name: symbol.toUpperCase(),
    buyUrl,
    website: buyUrl
  });
  const heliusResult = await ensureHeliusTracksContract(coin.contract);
  restartBitqueryStreamSoon();
  restartPumpPortalStreamSoon();
  restartNativeSolanaWatcherSoon();

  await ctx.reply([
    `This chat is now tracking $${coin.symbol} buys for ${coin.contract}.`,
    renderHeliusSyncStatus(heliusResult)
  ].filter(Boolean).join('\n'));
  await sendTelegramBackup(`Set ${coin.symbol} ${coin.contract} for chat ${ctx.chat.id}.`);
});

bot.command('testbuy', async (ctx) => {
  const symbol = getUpdateText(ctx).split(/\s+/)[1] ?? 'OGRE';
  const coin = await getCoin(symbol);

  if (!coin?.enabled) {
    await ctx.reply(`Unknown coin: ${symbol}`);
    return;
  }

  await postBuyAlert({
    coin,
    eventInput: {
      symbol: coin.symbol,
      contract: coin.contract,
      buyer: 'TESTBUY1111111111111111111111111111111111',
      tokenAmount: 100000,
      usdValue: 123.45,
      quoteAmount: 1,
      quoteSymbol: DEFAULT_QUOTE_SYMBOL,
      dex: 'test',
      txUrl: coin.website
    }
  });

  await ctx.reply(`Sent a test buy alert for $${coin.symbol}.`);
});

bot.command('addcoin', async (ctx) => {
  const payload = getUpdateText(ctx).replace(/^\/addcoin(@\w+)?\s*/i, '').trim();
  const match = payload.match(/^(\S+)\s+([^|]+)\|([^|]+)\|([^|]+)\|(.+)$/);

  if (!match) {
    await ctx.reply('Usage: /addcoin SYMBOL Name | chain | contract | buyUrl');
    return;
  }

  const [, symbol, name, chain, contract, buyUrl] = match;
  const coin = await upsertCoin({
    symbol,
    name: name.trim(),
    chain: chain.trim(),
    contract: contract.trim(),
    buyUrl: buyUrl.trim(),
    channels: [String(ctx.chat.id)]
  });
  const heliusResult = await ensureHeliusTracksContract(coin.contract);
  restartBitqueryStreamSoon();
  restartPumpPortalStreamSoon();
  restartNativeSolanaWatcherSoon();

  await ctx.reply([
    `Added $${coin.symbol} and linked it to this chat.`,
    renderHeliusSyncStatus(heliusResult)
  ].filter(Boolean).join('\n'));
  await sendTelegramBackup(`Added ${coin.symbol} ${coin.contract} for chat ${ctx.chat.id}.`);
});

bot.on('channel_post', handleFallbackCommand);
bot.on('message', handleFallbackCommand);

app.get('/', (_req, res) => {
  res.send('OGRE buy bot is running.');
});

app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

app.get('/api/debug/coins', async (_req, res) => {
  const store = await readStore();
  res.json({
    ok: true,
    coins: store.coins.map((coin) => ({
      symbol: coin.symbol,
      contract: coin.contract,
      enabled: coin.enabled,
      channels: coin.channels ?? []
    }))
  });
});

app.get('/api/debug/chat/:chatId', async (req, res) => {
  const coins = await getCoinsByChat(req.params.chatId);
  res.json({
    ok: true,
    chatId: req.params.chatId,
    coins: coins.map((coin) => ({
      symbol: coin.symbol,
      contract: coin.contract,
      channels: coin.channels ?? [],
      imageUrl: coin.imageUrl,
      buyUrl: coin.buyUrl
    }))
  });
});

app.get('/api/debug/pump/:contract', async (req, res) => {
  const meta = await getPumpFunMetadata(req.params.contract);
  res.json({
    ok: true,
    contract: req.params.contract,
    meta
  });
});

app.get('/api/telegram/info', async (_req, res) => {
  const webhookInfo = await bot.telegram.getWebhookInfo();
  res.json({
    ok: true,
    botUsername,
    webhookInfo
  });
});

app.get('/api/telegram/reset-webhook', async (req, res) => {
  if (WEBHOOK_SECRET && req.query.secret !== WEBHOOK_SECRET) {
    res.status(401).json({ error: 'Invalid secret' });
    return;
  }

  if (!telegramWebhookUrl) {
    res.status(400).json({ error: 'BASE_URL or TELEGRAM_WEBHOOK_URL is required to set Telegram webhook.' });
    return;
  }

  await bot.telegram.setWebhook(telegramWebhookUrl, {
    drop_pending_updates: true,
    allowed_updates: ['message', 'channel_post', 'my_chat_member']
  });
  const webhookInfo = await bot.telegram.getWebhookInfo();

  res.json({
    ok: true,
    telegramWebhookUrl,
    webhookInfo
  });
});

app.get('/api/test-alert/:symbol', async (req, res) => {
  if (WEBHOOK_SECRET && req.query.secret !== WEBHOOK_SECRET && req.header('x-bot-secret') !== WEBHOOK_SECRET) {
    res.status(401).json({ error: 'Invalid secret' });
    return;
  }

  const coin = await getCoin(req.params.symbol);
  if (!coin?.enabled) {
    res.status(404).json({ error: `Unknown coin: ${req.params.symbol}` });
    return;
  }

  const { event, results, duplicate } = await postBuyAlert({
    coin,
    eventInput: {
      symbol: coin.symbol,
      contract: coin.contract,
      buyer: 'LIVECHECK111111111111111111111111111111111',
      tokenAmount: 100000,
      usdValue: 123.45,
      quoteAmount: 1,
      quoteSymbol: DEFAULT_QUOTE_SYMBOL,
      buyerSolBalance: 5.25,
      dex: 'render-test',
      txUrl: coin.website
    }
  });

  res.json({
    ok: true,
    duplicate: Boolean(duplicate),
    channels: coin.channels ?? [],
    sent: results.filter((result) => result.status === 'fulfilled').length,
    failed: results
      .map((result, index) => ({ result, chatId: coin.channels?.[index] }))
      .filter((item) => item.result.status === 'rejected')
      .map((item) => ({
        chatId: item.chatId,
        error: item.result.reason?.description ?? item.result.reason?.message ?? String(item.result.reason)
      })),
    event
  });
});

app.get('/api/test-alert-contract/:contract', async (req, res) => {
  if (WEBHOOK_SECRET && req.query.secret !== WEBHOOK_SECRET && req.header('x-bot-secret') !== WEBHOOK_SECRET) {
    res.status(401).json({ error: 'Invalid secret' });
    return;
  }

  const coin = await getCoinByContract(req.params.contract);
  if (!coin?.enabled) {
    res.status(404).json({ error: `Unknown contract: ${req.params.contract}` });
    return;
  }

  const { event, results, duplicate } = await postBuyAlert({
    coin,
    eventInput: {
      symbol: coin.symbol,
      contract: coin.contract,
      buyer: 'LIVECHECK111111111111111111111111111111111',
      tokenAmount: 100000,
      usdValue: 123.45,
      quoteAmount: 1,
      quoteSymbol: DEFAULT_QUOTE_SYMBOL,
      buyerSolBalance: 5.25,
      dex: 'render-test',
      txUrl: coin.website || coin.buyUrl
    }
  });

  res.json({
    ok: true,
    duplicate: Boolean(duplicate),
    channels: getAlertChannels(coin),
    sent: results.filter((result) => result.status === 'fulfilled').length,
    failed: results
      .map((result, index) => ({ result, chatId: getAlertChannels(coin)[index] }))
      .filter((item) => item.result.status === 'rejected')
      .map((item) => ({
        chatId: item.chatId,
        error: item.result.reason?.description ?? item.result.reason?.message ?? String(item.result.reason)
      })),
    event
  });
});

app.post('/api/buy', async (req, res) => {
  if (WEBHOOK_SECRET && req.header('x-bot-secret') !== WEBHOOK_SECRET) {
    res.status(401).json({ error: 'Invalid secret' });
    return;
  }

  const parsed = buyEventSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }

  const coin = parsed.data.contract
    ? await getCoinByContract(parsed.data.contract)
    : await getCoin(parsed.data.symbol);

  if (!coin?.enabled) {
    res.status(404).json({ error: `Coin is not registered or is disabled.` });
    return;
  }

  const { event, results } = await postBuyAlert({ coin, eventInput: parsed.data });

  res.json({
    ok: true,
    sent: results.filter((result) => result.status === 'fulfilled').length,
    failed: results.filter((result) => result.status === 'rejected').length,
    event
  });
});

app.post('/api/helius', async (req, res) => {
  if (!isValidHeliusAuth(req.header('authorization'))) {
    res.status(401).json({ error: 'Invalid Helius authorization header' });
    return;
  }

  await saveLastHeliusPayload(req.body);
  const result = await processHeliusPayload(req.body);
  await notifyHeliusDebug(req.body, result);

  res.json(result);
});

app.get('/api/helius/replay-last', async (req, res) => {
  if (WEBHOOK_SECRET && req.query.secret !== WEBHOOK_SECRET) {
    res.status(401).json({ error: 'Invalid secret' });
    return;
  }

  try {
    const raw = await fs.readFile(path.resolve('data', 'last-helius-payload.json'), 'utf8');
    const debugPayload = JSON.parse(raw);
    const result = await processHeliusPayload(debugPayload.payload);
    res.json({ ...result, replayed: true });
  } catch (error) {
    res.status(404).json({ error: 'No saved Helius payload to replay.', detail: error.message });
  }
});

async function processHeliusPayload(payload) {
  const transactions = Array.isArray(payload) ? payload : [payload];
  const accepted = [];
  const ignored = [];

  for (const transaction of transactions) {
    const events = await parseHeliusTransaction(transaction);

    if (events.length === 0) {
      ignored.push({
        reason: 'no-buy-events-parsed',
        signature: transaction.signature,
        type: transaction.type,
        source: transaction.source,
        mintsSeen: getMintsSeen(transaction).slice(0, 10)
      });
    }

    for (const eventInput of events) {
      const coin = await getCoinByContract(eventInput.contract);

      if (!coin?.enabled) {
        ignored.push({ reason: 'untracked-contract', contract: eventInput.contract });
        continue;
      }

      const result = await postBuyAlert({ coin, eventInput });
      if (result.duplicate) {
        ignored.push({ reason: 'duplicate', signature: eventInput.txSignature });
      } else {
        accepted.push({ symbol: coin.symbol, signature: eventInput.txSignature });
      }
    }
  }

  return { ok: true, accepted, ignored };
}

async function notifyHeliusDebug(payload, result) {
  if (String(DEBUG_HELIUS_NOTIFICATIONS).toLowerCase() !== 'true') return;

  const debugChatId = DEBUG_HELIUS_CHAT_ID || ALERT_CHAT_ID;
  if (!debugChatId) return;

  const transactions = Array.isArray(payload) ? payload : [payload];
  const summary = [
    '<b>Helius webhook hit</b>',
    `Transactions: ${transactions.length}`,
    `Accepted buys: ${result.accepted.length}`,
    `Ignored: ${result.ignored.length}`,
    ...transactions.slice(0, 3).map((tx, index) => {
      const signature = tx.signature ? `${String(tx.signature).slice(0, 8)}...${String(tx.signature).slice(-6)}` : 'none';
      return `${index + 1}. ${tx.type ?? 'unknown'} / ${tx.source ?? 'unknown'} / ${signature}`;
    }),
    result.ignored[0] ? `First ignored: ${result.ignored[0].reason}` : null
  ].filter(Boolean).join('\n');

  try {
    await bot.telegram.sendMessage(debugChatId, summary, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
  } catch (error) {
    console.error('Could not send Helius debug notification:', error.message);
  }
}

function startHeliusPolling() {
  const interval = Math.max(5000, Number(HELIUS_POLL_INTERVAL_MS) || 15000);
  console.log(`Helius polling enabled. Scanning tracked contracts every ${interval}ms.`);

  pollTrackedContractsOnce().catch((error) => {
    console.error('Initial Helius poll failed:', error.message);
  });

  setInterval(() => {
    pollTrackedContractsOnce().catch((error) => {
      console.error('Helius poll failed:', error.message);
    });
  }, interval);
}

async function pollTrackedContractsOnce() {
  if (!HELIUS_API_KEY) {
    console.warn('Helius polling skipped. HELIUS_API_KEY is missing.');
    return { scannedContracts: 0, accepted: 0, ignored: 0 };
  }

  const store = await readStore();
  const contracts = Array.from(new Set(
    store.coins
      .filter((coin) => coin.enabled && coin.contract && (coin.channels ?? []).length > 0)
      .map((coin) => coin.contract)
  ));

  let accepted = 0;
  let ignored = 0;

  for (const contract of contracts) {
    const transactions = await fetchRecentHeliusTransactionsForAddress(contract);
    const result = await processHeliusPayload(transactions);
    accepted += result.accepted.length;
    ignored += result.ignored.length;
  }

  if (accepted > 0 || String(DEBUG_HELIUS_NOTIFICATIONS).toLowerCase() === 'true') {
    console.log(`Helius poll scanned ${contracts.length} contracts, accepted ${accepted}, ignored ${ignored}.`);
  }

  return { scannedContracts: contracts.length, accepted, ignored };
}

async function fetchRecentHeliusTransactionsForAddress(address) {
  const url = new URL(`https://api-mainnet.helius-rpc.com/v0/addresses/${address}/transactions`);
  url.searchParams.set('api-key', HELIUS_API_KEY);
  url.searchParams.set('limit', '10');

  const response = await fetch(url);
  const body = await response.json().catch(() => []);

  if (!response.ok) {
    throw new Error(`Helius address history failed for ${address}: ${body.error ?? body.message ?? response.status}`);
  }

  return Array.isArray(body) ? body : [];
}

async function startBitqueryStream() {
  if (!BITQUERY_TOKEN) {
    console.warn('Bitquery stream skipped. Set BITQUERY_TOKEN on Render.');
    return;
  }

  const contracts = await getTrackedContracts();
  if (contracts.length === 0) {
    console.warn('Bitquery stream skipped. No tracked contracts yet.');
    return;
  }

  if (bitquerySocket) {
    bitquerySocket.close();
    bitquerySocket = null;
  }

  const query = buildBitquerySolanaBuysSubscription(contracts);
  const socket = new WebSocket(`wss://streaming.bitquery.io/graphql?token=${BITQUERY_TOKEN}`, ['graphql-ws']);
  bitquerySocket = socket;

  socket.on('open', () => {
    console.log(`Connected to Bitquery stream for ${contracts.length} tracked CA(s).`);
    socket.send(JSON.stringify({ type: 'connection_init' }));
  });

  socket.on('message', async (data) => {
    try {
      const response = JSON.parse(data.toString());

      if (response.type === 'connection_ack') {
        socket.send(JSON.stringify({
          type: 'start',
          id: 'tracked-solana-buys',
          payload: { query }
        }));
        return;
      }

      if (response.type === 'data') {
        await processBitqueryMessage(response.payload?.data);
        return;
      }

      if (response.type === 'error') {
        console.error('Bitquery stream error:', JSON.stringify(response.payload));
      }
    } catch (error) {
      console.error('Could not process Bitquery message:', error.message);
    }
  });

  socket.on('close', () => {
    console.warn('Bitquery stream disconnected. Reconnecting soon.');
    if (bitquerySocket === socket) {
      bitquerySocket = null;
      restartBitqueryStreamSoon();
    }
  });

  socket.on('error', (error) => {
    console.error('Bitquery websocket error:', error.message);
  });
}

async function getTrackedContracts() {
  const store = await readStore();
  return Array.from(new Set(
    store.coins
      .filter((coin) => coin.enabled && coin.contract && (coin.channels ?? []).length > 0)
      .map((coin) => coin.contract)
  ));
}

function buildBitquerySolanaBuysSubscription(contracts) {
  const quotedContracts = contracts.map((contract) => `"${contract}"`).join(', ');

  return `
    subscription TrackedSolanaBuys {
      Solana {
        DEXTrades(
          where: {
            Transaction: { Result: { Success: true } }
            Trade: { Buy: { Currency: { MintAddress: { in: [${quotedContracts}] } } } }
          }
        ) {
          Block { Time }
          Transaction { Signature }
          Trade {
            Dex { ProtocolName ProtocolFamily }
            Buy {
              Amount
              PriceInUSD
              Account { Address }
              Currency { MintAddress Symbol Name }
            }
            Sell {
              Amount
              Account { Address }
              Currency { MintAddress Symbol Name }
            }
          }
        }
      }
    }
  `;
}

async function processBitqueryMessage(data) {
  const trades = data?.Solana?.DEXTrades ?? [];

  for (const row of trades) {
    const buy = row.Trade?.Buy;
    const sell = row.Trade?.Sell;
    const contract = buy?.Currency?.MintAddress;
    const coin = contract ? await getCoinByContract(contract) : null;

    if (!coin?.enabled) continue;

    const tokenAmount = Number(buy.Amount ?? 0);
    if (tokenAmount <= 0) continue;

    const priceUsd = Number(buy.PriceInUSD ?? 0);
    const sellSymbol = sell?.Currency?.Symbol || DEFAULT_QUOTE_SYMBOL;
    const eventInput = {
      contract,
      buyer: buy.Account?.Address ?? sell?.Account?.Address,
      tokenAmount,
      usdValue: Number.isFinite(priceUsd) ? tokenAmount * priceUsd : 0,
      quoteAmount: Number(sell?.Amount ?? 0) || undefined,
      quoteSymbol: sellSymbol,
      dex: row.Trade?.Dex?.ProtocolName ?? row.Trade?.Dex?.ProtocolFamily ?? 'Bitquery DEX',
      txSignature: row.Transaction?.Signature,
      txUrl: row.Transaction?.Signature ? `https://solscan.io/tx/${row.Transaction.Signature}` : undefined
    };

    await postBuyAlert({ coin, eventInput });
  }
}

function restartBitqueryStreamSoon() {
  if (String(ENABLE_BITQUERY_STREAM).toLowerCase() !== 'true') return;

  clearTimeout(bitqueryRestartTimer);
  bitqueryRestartTimer = setTimeout(() => {
    startBitqueryStream().catch((error) => {
      console.error('Bitquery stream restart failed:', error.message);
    });
  }, 3000);
}

async function startPumpPortalStream() {
  const contracts = await getTrackedContracts();
  if (contracts.length === 0) {
    console.warn('PumpPortal stream skipped. No tracked contracts yet.');
    return;
  }

  if (pumpPortalSocket) {
    pumpPortalSocket.close();
    pumpPortalSocket = null;
  }

  const url = PUMPPORTAL_API_KEY
    ? `wss://pumpportal.fun/api/data?api-key=${PUMPPORTAL_API_KEY}`
    : 'wss://pumpportal.fun/api/data';
  const socket = new WebSocket(url);
  pumpPortalSocket = socket;

  socket.on('open', () => {
    console.log(`Connected to PumpPortal stream for ${contracts.length} tracked CA(s).`);
    socket.send(JSON.stringify({
      method: 'subscribeTokenTrade',
      keys: contracts
    }));
  });

  socket.on('message', async (data) => {
    try {
      const event = JSON.parse(data.toString());
      await processPumpPortalTrade(event);
    } catch (error) {
      console.error('Could not process PumpPortal message:', error.message);
    }
  });

  socket.on('close', () => {
    console.warn('PumpPortal stream disconnected. Reconnecting soon.');
    if (pumpPortalSocket === socket) {
      pumpPortalSocket = null;
      restartPumpPortalStreamSoon();
    }
  });

  socket.on('error', (error) => {
    console.error('PumpPortal websocket error:', error.message);
  });
}

async function processPumpPortalTrade(event) {
  if (!event?.mint || String(event.txType ?? '').toLowerCase() !== 'buy') return;

  const coin = await getCoinByContract(event.mint);
  if (!coin?.enabled) return;

  await postBuyAlert({
    coin,
    eventInput: {
      contract: event.mint,
      buyer: event.traderPublicKey,
      tokenAmount: Number(event.tokenAmount ?? event.tokensBought ?? 0),
      usdValue: 0,
      quoteAmount: Number(event.solAmount ?? event.solSpent ?? 0) || undefined,
      quoteSymbol: 'SOL',
      marketCap: event.marketCapUsd,
      dex: event.pool ? `PumpPortal ${event.pool}` : 'PumpPortal',
      txSignature: event.signature,
      txUrl: event.signature ? `https://solscan.io/tx/${event.signature}` : undefined
    }
  });
}

function restartPumpPortalStreamSoon() {
  if (String(ENABLE_PUMPPORTAL_STREAM).toLowerCase() !== 'true') return;

  clearTimeout(pumpPortalRestartTimer);
  pumpPortalRestartTimer = setTimeout(() => {
    startPumpPortalStream().catch((error) => {
      console.error('PumpPortal stream restart failed:', error.message);
    });
  }, 3000);
}

async function startNativeSolanaWatcher() {
  const contracts = await getTrackedContracts();
  if (contracts.length === 0) {
    console.warn('Native Solana watcher skipped. No tracked contracts yet.');
    return;
  }

  await stopNativeSolanaWatcher();

  const wsUrl = SOLANA_WS_URL || SOLANA_RPC_HTTP.replace(/^https:/, 'wss:').replace(/^http:/, 'ws:');
  nativeSolanaConnection = new Connection(SOLANA_RPC_HTTP, {
    commitment: 'confirmed',
    wsEndpoint: wsUrl
  });

  const watchAddresses = new Map();

  for (const contract of contracts) {
    try {
      const mint = new PublicKey(contract);
      watchAddresses.set(mint.toBase58(), { contract, kind: 'mint' });
      watchAddresses.set(getPumpBondingCurvePda(mint).toBase58(), { contract, kind: 'pump-bonding-curve' });
    } catch (error) {
      console.error(`Invalid Solana mint for native watcher: ${contract}`, error.message);
    }
  }

  for (const [address, info] of watchAddresses) {
    const subscriptionId = nativeSolanaConnection.onLogs(
      new PublicKey(address),
      (logs) => handleNativeSolanaLogs(logs, info).catch((error) => {
        console.error('Native Solana log handler failed:', error.message);
      }),
      'confirmed'
    );
    nativeSolanaSubscriptionIds.push(subscriptionId);
  }

  console.log(`Native Solana watcher subscribed to ${watchAddresses.size} address(es) for ${contracts.length} tracked CA(s).`);
}

async function stopNativeSolanaWatcher() {
  if (!nativeSolanaConnection) {
    nativeSolanaSubscriptionIds = [];
    return;
  }

  await Promise.allSettled(
    nativeSolanaSubscriptionIds.map((id) => nativeSolanaConnection.removeOnLogsListener(id))
  );
  nativeSolanaSubscriptionIds = [];
}

function restartNativeSolanaWatcherSoon() {
  if (String(ENABLE_NATIVE_SOLANA_WATCHER).toLowerCase() !== 'true') return;

  setTimeout(() => {
    startNativeSolanaWatcher().catch((error) => {
      console.error('Native Solana watcher restart failed:', error.message);
    });
  }, 3000);
}

function getPumpBondingCurvePda(mint) {
  const [bondingCurve] = PublicKey.findProgramAddressSync(
    [Buffer.from('bonding-curve'), mint.toBuffer()],
    PUMP_PROGRAM_ID
  );
  return bondingCurve;
}

async function handleNativeSolanaLogs(logs, info) {
  if (logs.err || !logs.signature) return;
  if (nativeSolanaSeenSignatures.has(logs.signature)) return;
  nativeSolanaSeenSignatures.add(logs.signature);

  if (nativeSolanaSeenSignatures.size > 5000) {
    const oldest = nativeSolanaSeenSignatures.values().next().value;
    nativeSolanaSeenSignatures.delete(oldest);
  }

  const transaction = await nativeSolanaConnection.getParsedTransaction(logs.signature, {
    commitment: 'confirmed',
    maxSupportedTransactionVersion: 0
  });
  if (!transaction?.meta) return;

  const eventInput = parseNativeSolanaBuy(transaction, info.contract, logs.signature);
  if (!eventInput) return;

  const coin = await getCoinByContract(info.contract);
  if (!coin?.enabled) return;

  await postBuyAlert({ coin, eventInput });
}

function parseNativeSolanaBuy(transaction, contract, signature) {
  const meta = transaction.meta;
  const accountKeys = transaction.transaction.message.accountKeys.map((key) => key.pubkey.toBase58());
  const tokenGain = findLargestTokenGain(meta, contract);
  if (!tokenGain || tokenGain.amount <= 0) return null;

  const buyer = tokenGain.owner || accountKeys[0];
  const solSpent = findSolSpentByOwner(meta, accountKeys, buyer);
  if (solSpent <= 0) return null;

  return {
    contract,
    buyer,
    tokenAmount: tokenGain.amount,
    usdValue: 0,
    quoteAmount: solSpent,
    quoteSymbol: 'SOL',
    dex: 'Native Solana watcher',
    txSignature: signature,
    txUrl: `https://solscan.io/tx/${signature}`
  };
}

function findLargestTokenGain(meta, contract) {
  const pre = new Map((meta.preTokenBalances ?? [])
    .filter((balance) => balance.mint === contract)
    .map((balance) => [tokenBalanceKey(balance), uiTokenAmount(balance)]));
  const gains = (meta.postTokenBalances ?? [])
    .filter((balance) => balance.mint === contract)
    .map((balance) => {
      const before = pre.get(tokenBalanceKey(balance)) ?? 0;
      return {
        owner: balance.owner,
        accountIndex: balance.accountIndex,
        amount: uiTokenAmount(balance) - before
      };
    })
    .filter((gain) => gain.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  return gains[0];
}

function tokenBalanceKey(balance) {
  return `${balance.accountIndex}:${balance.owner ?? ''}`;
}

function uiTokenAmount(balance) {
  return Number(balance.uiTokenAmount?.uiAmountString ?? balance.uiTokenAmount?.uiAmount ?? 0);
}

function findSolSpentByOwner(meta, accountKeys, owner) {
  const ownerIndex = accountKeys.indexOf(owner);
  const candidateIndexes = ownerIndex >= 0 ? [ownerIndex, 0] : [0];

  for (const index of candidateIndexes) {
    const pre = Number(meta.preBalances?.[index] ?? 0);
    const post = Number(meta.postBalances?.[index] ?? 0);
    const diff = pre - post;
    if (diff > 0) return diff / 1_000_000_000;
  }

  return 0;
}

function startKeepAlive() {
  const targetUrl = KEEP_ALIVE_URL || (BASE_URL ? `${BASE_URL.replace(/\/$/, '')}/health` : null);
  if (!targetUrl) {
    console.warn('Keep-alive skipped. Set BASE_URL or KEEP_ALIVE_URL.');
    return;
  }

  const interval = Math.max(60000, Number(KEEP_ALIVE_INTERVAL_MS) || 600000);
  console.log(`Keep-alive enabled. Pinging ${targetUrl} every ${interval}ms.`);

  pingKeepAlive(targetUrl);
  setInterval(() => pingKeepAlive(targetUrl), interval);
}

async function pingKeepAlive(targetUrl) {
  try {
    const response = await fetch(targetUrl);
    console.log(`Keep-alive ping ${targetUrl}: ${response.status}`);
  } catch (error) {
    console.error(`Keep-alive ping failed for ${targetUrl}:`, error.message);
  }
}

function startDexScreenerPolling() {
  const interval = Math.max(10000, Number(DEXSCREENER_POLL_INTERVAL_MS) || 20000);
  console.log(`DEX Screener polling enabled. Checking tracked contracts every ${interval}ms.`);

  pollDexScreenerOnce().catch((error) => {
    console.error('Initial DEX Screener poll failed:', error.message);
  });

  setInterval(() => {
    pollDexScreenerOnce().catch((error) => {
      console.error('DEX Screener poll failed:', error.message);
    });
  }, interval);
}

async function pollDexScreenerOnce() {
  const store = await readStore();
  const coins = store.coins.filter((coin) => coin.enabled && coin.contract && (coin.channels ?? []).length > 0);

  for (const coin of coins) {
    const pair = await getBestDexScreenerPair(coin.contract);
    if (!pair) continue;

    const stateKey = `${coin.contract}:${pair.pairAddress}`;
    const currentBuys = Number(pair.txns?.m5?.buys ?? pair.txns?.h1?.buys ?? 0);
    const currentVolume = Number(pair.volume?.m5 ?? pair.volume?.h1 ?? 0);
    const previous = dexScreenerState.get(stateKey);

    dexScreenerState.set(stateKey, {
      buys: currentBuys,
      volume: currentVolume,
      seenAt: Date.now()
    });

    if (!previous) continue;

    const buyDelta = currentBuys - previous.buys;
    if (buyDelta <= 0) continue;

    const volumeDelta = Math.max(0, currentVolume - previous.volume);
    await postBuyAlert({
      coin,
      eventInput: {
        contract: coin.contract,
        buyer: 'DEXSCREENER_AGGREGATE',
        tokenAmount: 0,
        usdValue: volumeDelta,
        aggregateBuys: buyDelta,
        aggregateVolumeUsd: volumeDelta,
        marketCap: pair.marketCap,
        dex: `${pair.dexId ?? 'dex'} aggregate`,
        txSignature: `dexscreener-${pair.pairAddress}-${currentBuys}-${Date.now()}`,
        txUrl: pair.url
      }
    });
  }
}

async function getBestDexScreenerPair(contract) {
  try {
    const response = await fetch(`https://api.dexscreener.com/tokens/v1/solana/${contract}`);
    if (!response.ok) return null;

    const pairs = await response.json();
    if (!Array.isArray(pairs) || pairs.length === 0) return null;

    return pairs
      .filter((pair) => pair.pairAddress)
      .sort((a, b) => Number(b.liquidity?.usd ?? 0) - Number(a.liquidity?.usd ?? 0))[0] ?? null;
  } catch (error) {
    console.error(`DEX Screener polling failed for ${contract}:`, error.message);
    return null;
  }
}

app.get('/api/helius/last', async (_req, res) => {
  try {
    const raw = await fs.readFile(path.resolve('data', 'last-helius-payload.json'), 'utf8');
    res.type('json').send(raw);
  } catch {
    res.status(404).json({ error: 'No Helius payload has reached this bot yet.' });
  }
});

app.get('/api/helius/last-summary', async (_req, res) => {
  try {
    const raw = await fs.readFile(path.resolve('data', 'last-helius-payload.json'), 'utf8');
    const debugPayload = JSON.parse(raw);
    const transactions = Array.isArray(debugPayload.payload) ? debugPayload.payload : [debugPayload.payload];
    res.json({
      ok: true,
      receivedAt: debugPayload.receivedAt,
      transactions: transactions.map((tx) => ({
        signature: tx.signature,
        type: tx.type,
        source: tx.source,
        feePayer: tx.feePayer,
        mintsSeen: getMintsSeen(tx),
        tokenTransfers: (tx.tokenTransfers ?? []).length,
        nativeTransfers: (tx.nativeTransfers ?? []).length,
        accountData: (tx.accountData ?? []).length,
        hasSwapEvent: Boolean(tx.events?.swap)
      }))
    });
  } catch (error) {
    res.status(404).json({ error: 'No saved Helius payload to summarize.', detail: error.message });
  }
});

bot.catch((error, ctx) => {
  console.error(`Telegram error for update ${ctx.update?.update_id ?? 'unknown'}:`, error);
});

async function main() {
  app.listen(Number(PORT), () => {
    console.log(`Buy bot API listening on http://localhost:${PORT}`);
  });

  const me = await bot.telegram.getMe();
  botUsername = me.username;
  console.log(`Telegram bot connected as @${me.username}`);

  await bot.telegram.setMyCommands([
    { command: 'start', description: 'Start the bot' },
    { command: 'help', description: 'Show bot commands' },
    { command: 'coins', description: 'List tracked coins' },
    { command: 'trending', description: 'Show 24h trending volume' },
    { command: 'chatid', description: 'Show this chat id' },
    { command: 'chats', description: 'Show tracked chats' },
    { command: 'backup_here', description: 'Use this chat for backups' },
    { command: 'backup_now', description: 'Post a backup now' },
    { command: 'restore_backup', description: 'Restore from replied backup' },
    { command: 'sync_helius', description: 'Sync tracked CAs to Helius' },
    { command: 'scan_now', description: 'Scan tracked CAs for recent buys' },
    { command: 'track', description: 'Track a coin in this chat' },
    { command: 'setcoin', description: 'Register this chat for a coin CA' },
    { command: 'setca', description: 'Register this chat for a coin CA' },
    { command: 'testbuy', description: 'Send a test buy alert' },
    { command: 'addcoin', description: 'Register another coin' }
  ]);

  if (telegramWebhookUrl) {
    await bot.telegram.setWebhook(telegramWebhookUrl, {
      drop_pending_updates: true,
      allowed_updates: ['message', 'channel_post', 'my_chat_member']
    });
    console.log(`Telegram webhook set to ${telegramWebhookUrl}`);
  } else {
    await bot.telegram.deleteWebhook({
      drop_pending_updates: true
    });
    await bot.launch({
      dropPendingUpdates: true
    });
    console.log('Telegram polling started. Leave this window open.');
  }

  if (String(ENABLE_HELIUS_POLLING).toLowerCase() === 'true') {
    startHeliusPolling();
  }

  if (String(ENABLE_BITQUERY_STREAM).toLowerCase() === 'true') {
    startBitqueryStream().catch((error) => {
      console.error('Bitquery stream failed to start:', error.message);
    });
  }

  if (String(ENABLE_PUMPPORTAL_STREAM).toLowerCase() === 'true') {
    startPumpPortalStream().catch((error) => {
      console.error('PumpPortal stream failed to start:', error.message);
    });
  }

  if (String(ENABLE_NATIVE_SOLANA_WATCHER).toLowerCase() === 'true') {
    startNativeSolanaWatcher().catch((error) => {
      console.error('Native Solana watcher failed to start:', error.message);
    });
  }

  if (String(ENABLE_DEXSCREENER_POLLING).toLowerCase() === 'true') {
    startDexScreenerPolling();
  }

  if (String(ENABLE_KEEP_ALIVE).toLowerCase() === 'true') {
    startKeepAlive();
  }
}

main().catch((error) => {
  console.error('Bot failed to start.');
  console.error(error);

  if (String(error.message ?? '').includes('409')) {
    console.error('Another copy of this bot is already running. Close the other terminal/process and try again.');
  }

  process.exit(1);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

function getUpdateText(ctx) {
  return ctx.message?.text
    ?? ctx.message?.caption
    ?? ctx.channelPost?.text
    ?? ctx.channelPost?.caption
    ?? '';
}

async function handleFallbackCommand(ctx) {
  const parsed = parseCommandFromText(getUpdateText(ctx));
  if (!parsed) return;

  const { command, args } = parsed;

  if (command === 'help' || command === 'start') {
    await showHelp(ctx);
    return;
  }

  if (command === 'chatid') {
    await ctx.reply(`This chat id is: ${ctx.chat.id}`);
    return;
  }

  if (command === 'chats') {
    await replyWithTrackedChats(ctx);
    return;
  }

  if (command === 'backup_here') {
    telegramBackupChatId = String(ctx.chat.id);
    await sendTelegramBackup('Backup channel set from /backup_here.');
    await ctx.reply('This chat is now the Telegram backup channel. Backups will post here after setup changes.');
    return;
  }

  if (command === 'backup_now') {
    if (!telegramBackupChatId) telegramBackupChatId = String(ctx.chat.id);
    await sendTelegramBackup('Manual backup from /backup_now.');
    await ctx.reply('Backup posted.');
    return;
  }

  if (command === 'restore_backup') {
    const restored = await restoreTelegramBackupFromReply(ctx);
    if (restored) {
      await ctx.reply(`Restored backup: ${restored.coins.length} coins, ${restored.events.length} events.`);
      restartBitqueryStreamSoon();
      restartPumpPortalStreamSoon();
      restartNativeSolanaWatcherSoon();
    }
    return;
  }

  if (command === 'setcoin' || command === 'setca') {
    await setCoinForChat(ctx, args);
    return;
  }

  if (command === 'track') {
    await trackSymbolForChat(ctx, args[0]);
    return;
  }

  if (command === 'testbuy') {
    await sendTestBuy(ctx, args[0] ?? 'OGRE');
  }
}

function parseCommandFromText(rawText) {
  let text = rawText.trim();
  if (!text) return null;

  const mentionPattern = botUsername ? new RegExp(`^@${escapeRegExp(botUsername)}\\b\\s*`, 'i') : /^@\w+\b\s*/i;
  text = text.replace(mentionPattern, '').trim();

  if (!text.startsWith('/')) {
    const firstWord = text.split(/\s+/)[0]?.toLowerCase();
    const mentionOnlyCommands = new Set(['help', 'start', 'chatid', 'chats', 'setcoin', 'setca', 'track', 'testbuy']);
    if (!mentionOnlyCommands.has(firstWord)) return null;
  }

  const [rawCommand, ...args] = text.split(/\s+/);
  const command = rawCommand.replace(/^\//, '').split('@')[0].toLowerCase();
  return { command, args };
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function replyWithTrackedChats(ctx) {
  const chats = await getTrackedChats();
  if (chats.length === 0) {
    await ctx.reply('No chats are tracking coins yet.');
    return;
  }

  await ctx.reply(chats.map((item) => `${item.chatId} -> $${item.symbol} (${item.contract})`).join('\n'));
}

async function setCoinForChat(ctx, args) {
  const [symbol, contract, buyUrlArg] = args;

  if (!symbol || !contract) {
    await ctx.reply('Usage: /setcoin SYMBOL CONTRACT');
    return;
  }

  const tokenMeta = await getTokenMetadata(contract);
  const buyUrl = buyUrlArg || `https://pump.fun/coin/${contract}`;
  const coin = await addChannelToCoinByContract(contract, ctx.chat.id, {
    symbol,
    name: tokenMeta?.name || symbol.toUpperCase(),
    buyUrl,
    website: tokenMeta?.website || buyUrl,
    imageUrl: tokenMeta?.imageUrl,
    twitter: tokenMeta?.twitter,
    telegram: tokenMeta?.telegram
  });
  const heliusResult = await ensureHeliusTracksContract(coin.contract);
  restartBitqueryStreamSoon();
  restartPumpPortalStreamSoon();
  restartNativeSolanaWatcherSoon();

  await ctx.reply([
    `This chat is now tracking $${coin.symbol} buys for ${coin.contract}.`,
    renderHeliusSyncStatus(heliusResult)
  ].filter(Boolean).join('\n'));
  await sendTelegramBackup(`Set ${coin.symbol} ${coin.contract} for chat ${ctx.chat.id}.`);
}

async function trackSymbolForChat(ctx, symbol) {
  if (!symbol) {
    await ctx.reply('Usage: /track OGRE');
    return;
  }

  try {
    const coin = await addChannelToCoin(symbol, ctx.chat.id);
    const heliusResult = await ensureHeliusTracksContract(coin.contract);
    await ctx.reply([
      `This chat is now tracking $${coin.symbol}. Make sure the bot is admin if this is a channel.`,
      renderHeliusSyncStatus(heliusResult)
    ].filter(Boolean).join('\n'));
    await sendTelegramBackup(`Tracked $${coin.symbol} in chat ${ctx.chat.id}.`);
  } catch (error) {
    await ctx.reply(error.message);
  }
}

async function sendTestBuy(ctx, symbol) {
  const coin = await getCoin(symbol);

  if (!coin?.enabled) {
    await ctx.reply(`Unknown coin: ${symbol}`);
    return;
  }

  await postBuyAlert({
    coin,
    eventInput: {
      symbol: coin.symbol,
      contract: coin.contract,
      buyer: 'TESTBUY1111111111111111111111111111111111',
      tokenAmount: 100000,
      usdValue: 123.45,
      quoteAmount: 1,
      quoteSymbol: DEFAULT_QUOTE_SYMBOL,
      dex: 'test',
      txUrl: coin.website
    }
  });

  await ctx.reply(`Sent a test buy alert for $${coin.symbol}.`);
}

async function sendTelegramBackup(reason = 'Backup') {
  if (!telegramBackupChatId) return;

  try {
    const store = await readStore();
    const backup = {
      type: 'OgreBuyBotBackup',
      version: 1,
      createdAt: new Date().toISOString(),
      reason,
      store
    };

    await bot.telegram.sendMessage(
      telegramBackupChatId,
      [
        '<b>OgreBuyBot Backup</b>',
        escapeHtmlForTelegram(reason),
        '<pre>',
        escapeHtmlForTelegram(JSON.stringify(backup)),
        '</pre>'
      ].join('\n'),
      { parse_mode: 'HTML' }
    );
  } catch (error) {
    console.error('Telegram backup failed:', error.message);
  }
}

async function restoreTelegramBackupFromReply(ctx) {
  const replyText = ctx.message?.reply_to_message?.text
    ?? ctx.message?.reply_to_message?.caption
    ?? ctx.channelPost?.reply_to_message?.text
    ?? ctx.channelPost?.reply_to_message?.caption
    ?? '';

  const backup = parseTelegramBackup(replyText);
  if (!backup?.store) {
    await ctx.reply('Reply to an OgreBuyBot backup message, then run /restore_backup.');
    return null;
  }

  return replaceStore(backup.store);
}

function parseTelegramBackup(text) {
  const trimmed = String(text ?? '').trim();
  const jsonMatch = trimmed.match(/\{[\s\S]*\}$/);
  if (!jsonMatch) return null;

  try {
    const parsed = JSON.parse(jsonMatch[0]);
    return parsed.type === 'OgreBuyBotBackup' ? parsed : null;
  } catch {
    return null;
  }
}

function escapeHtmlForTelegram(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

async function postBuyAlert({ coin, eventInput }) {
  const event = await recordBuyEvent({
    ...eventInput,
    symbol: coin.symbol,
    contract: eventInput.contract ?? coin.contract,
    quoteSymbol: eventInput.quoteSymbol ?? DEFAULT_QUOTE_SYMBOL
  });

  if (!event) {
    return { duplicate: true, results: [] };
  }

  const trending = await getTrendingCoins(Number(TRENDING_LIMIT));
  const primaryCoin = await getPrimaryCoin();
  const tokenMeta = await getTokenMetadata(coin.contract);
  const message = renderBuyAlert({ coin, event, trending, primaryCoin, tokenMeta });
  const channels = getAlertChannels(coin);

  const results = await Promise.allSettled(
    channels.map((chatId) => sendBuyAlertToChat(chatId, message, tokenMeta?.imageUrl))
  );

  results.forEach((result, index) => {
    if (result.status === 'rejected') {
      console.error(`Failed to send $${coin.symbol} buy alert to chat ${channels[index]}:`, result.reason);
    }
  });

  return { event, results };
}

async function sendBuyAlertToChat(chatId, message, imageUrl) {
  if (imageUrl) {
    try {
      return await bot.telegram.sendPhoto(chatId, imageUrl, {
        caption: message,
        parse_mode: 'HTML'
      });
    } catch (error) {
      console.error(`Failed to send token image to ${chatId}, falling back to text:`, error.message);
    }
  }

  return bot.telegram.sendMessage(chatId, message, {
    parse_mode: 'HTML',
    disable_web_page_preview: true
  });
}

function getAlertChannels(coin) {
  const configuredChannels = coin.channels ?? [];
  const fallbackChannels = ALERT_CHAT_ID
    ? ALERT_CHAT_ID.split(',').map((chatId) => chatId.trim()).filter(Boolean)
    : [];

  if (configuredChannels.length > 0) {
    return Array.from(new Set(configuredChannels));
  }

  return Array.from(new Set(fallbackChannels));
}

async function parseHeliusTransaction(transaction) {
  const tokenTransfers = [
    ...(transaction.tokenTransfers ?? []),
    ...getSwapTokenOutputs(transaction),
    ...getTokenBalanceChangeOutputs(transaction)
  ];
  const nativeTransfers = transaction.nativeTransfers ?? [];
  const signature = transaction.signature;
  const source = transaction.source ?? transaction.type ?? 'helius';
  const events = [];

  for (const transfer of tokenTransfers) {
    const contract = transfer.mint;
    if (!contract) continue;

    const buyer = transfer.toUserAccount ?? transfer.userAccount ?? transaction.feePayer;
    if (!buyer) continue;

    const solSpent = getSolSpentByWallet(transaction, nativeTransfers, buyer);
    if (solSpent <= 0 && !isLikelySwapBuy(transaction)) continue;

    const buyerSolBalance = await getSolBalance(buyer);
    const priceUsd = await getTokenPriceUsd(contract);
    const tokenAmount = Number(transfer.tokenAmount ?? 0);
    if (tokenAmount <= 0) continue;

    events.push({
      contract,
      buyer,
      tokenAmount,
      usdValue: priceUsd ? tokenAmount * priceUsd : 0,
      quoteAmount: solSpent > 0 ? solSpent : undefined,
      quoteSymbol: 'SOL',
      buyerSolBalance,
      dex: source,
      txSignature: signature,
      txUrl: signature ? `https://solscan.io/tx/${signature}` : undefined
    });
  }

  return events;
}

function getSwapTokenOutputs(transaction) {
  const outputs = transaction.events?.swap?.tokenOutputs ?? [];

  return outputs.map((output) => ({
    mint: output.mint,
    toUserAccount: output.userAccount ?? output.toUserAccount ?? output.account,
    tokenAmount: output.tokenAmount ?? parseRawTokenAmount(output.rawTokenAmount)
  }));
}

function getTokenBalanceChangeOutputs(transaction) {
  return (transaction.accountData ?? []).flatMap((account) => {
    return (account.tokenBalanceChanges ?? [])
      .map((change) => {
        const tokenAmount = getTokenAmountFromBalanceChange(change);
        return {
          mint: change.mint,
          toUserAccount: change.userAccount ?? account.account,
          tokenAmount
        };
      })
      .filter((change) => change.mint && Number(change.tokenAmount ?? 0) > 0);
  });
}

function getMintsSeen(transaction) {
  return Array.from(new Set([
    ...(transaction.tokenTransfers ?? []).map((transfer) => transfer.mint),
    ...getSwapTokenOutputs(transaction).map((transfer) => transfer.mint),
    ...getTokenBalanceChangeOutputs(transaction).map((transfer) => transfer.mint)
  ].filter(Boolean)));
}

function getTokenAmountFromBalanceChange(change) {
  const raw = change.rawTokenAmount;
  if (raw) {
    const amount = Number(raw.tokenAmount ?? raw.amount);
    const decimals = Number(raw.decimals ?? 0);
    if (Number.isFinite(amount)) return amount / 10 ** decimals;
  }

  return Number(change.tokenAmount ?? change.uiTokenAmount ?? 0);
}

function isLikelySwapBuy(transaction) {
  const type = String(transaction.type ?? '').toUpperCase();
  const source = String(transaction.source ?? '').toUpperCase();
  return type === 'SWAP'
    || Boolean(transaction.events?.swap)
    || source.includes('PUMP')
    || source.includes('RAYDIUM')
    || source.includes('JUPITER')
    || source.includes('METEORA');
}

function parseRawTokenAmount(rawTokenAmount) {
  if (!rawTokenAmount) return undefined;

  const amount = Number(rawTokenAmount.tokenAmount ?? rawTokenAmount.amount);
  const decimals = Number(rawTokenAmount.decimals ?? 0);
  if (!Number.isFinite(amount)) return undefined;

  return amount / 10 ** decimals;
}

function getSolSpentByWallet(transaction, nativeTransfers, wallet) {
  const lamportsSpent = nativeTransfers
    .filter((nativeTransfer) => nativeTransfer.fromUserAccount === wallet)
    .reduce((total, nativeTransfer) => total + Number(nativeTransfer.amount ?? 0), 0);

  if (lamportsSpent > 0) {
    return lamportsSpent / 1_000_000_000;
  }

  const swapNativeInput = transaction.events?.swap?.nativeInput;
  if (swapNativeInput?.amount) {
    const accountMatches = !swapNativeInput.account || swapNativeInput.account === wallet;
    if (accountMatches) {
      return Number(swapNativeInput.amount) / 1_000_000_000;
    }
  }

  const balanceChange = (transaction.accountData ?? [])
    .filter((account) => account.account === wallet && Number(account.nativeBalanceChange ?? 0) < 0)
    .reduce((total, account) => total + Math.abs(Number(account.nativeBalanceChange ?? 0)), 0);

  return balanceChange / 1_000_000_000;
}

async function getTokenPriceUsd(contract) {
  try {
    const response = await fetch(`https://api.dexscreener.com/tokens/v1/solana/${contract}`);
    if (!response.ok) return undefined;

    const pairs = await response.json();
    const bestPair = Array.isArray(pairs)
      ? pairs.sort((a, b) => Number(b.liquidity?.usd ?? 0) - Number(a.liquidity?.usd ?? 0))[0]
      : null;
    const price = Number(bestPair?.priceUsd);

    return Number.isFinite(price) && price > 0 ? price : undefined;
  } catch (error) {
    console.error(`Could not fetch USD price for ${contract}:`, error.message);
    return undefined;
  }
}

async function getTokenMetadata(contract) {
  if (!contract) return null;

  const storedCoin = await getCoinByContract(contract);
  const storedMeta = storedCoin ? {
    source: 'store',
    name: storedCoin.name,
    symbol: storedCoin.symbol,
    imageUrl: storedCoin.imageUrl,
    twitter: storedCoin.twitter,
    telegram: storedCoin.telegram,
    website: storedCoin.website
  } : null;

  const pumpMeta = await getPumpFunMetadata(contract);
  if (pumpMeta?.imageUrl || pumpMeta?.bondingProgress != null) {
    return { ...storedMeta, ...pumpMeta };
  }

  const heliusMeta = await getHeliusAssetMetadata(contract);
  return { ...storedMeta, ...(heliusMeta ?? pumpMeta ?? {}) };
}

async function getPumpFunMetadata(contract) {
  try {
    const response = await fetch(`https://frontend-api-v3.pump.fun/coins/${contract}`);
    if (!response.ok) return null;

    const coin = await response.json();
    const complete = Boolean(coin.complete);
    const bondingProgress = getPumpFunBondingProgress(coin);

    return {
      source: 'pump.fun',
      name: coin.name,
      symbol: coin.symbol,
      imageUrl: coin.image_uri || coin.image || coin.metadata?.image,
      complete,
      bondingProgress,
      rawProgressFields: {
        bonding_curve_progress: coin.bonding_curve_progress,
        bondingCurveProgress: coin.bondingCurveProgress,
        graduationPercent: coin.graduationPercent,
        progress: coin.progress,
        real_token_reserves: coin.real_token_reserves,
        initial_real_token_reserves: coin.initial_real_token_reserves,
        real_sol_reserves: coin.real_sol_reserves,
        usd_market_cap: coin.usd_market_cap,
        market_cap: coin.market_cap
      },
      marketCapUsd: coin.usd_market_cap ?? coin.market_cap,
      twitter: coin.twitter,
      telegram: coin.telegram,
      website: coin.website
    };
  } catch (error) {
    console.error(`Could not fetch Pump.fun metadata for ${contract}:`, error.message);
    return null;
  }
}

function getPumpFunBondingProgress(coin) {
  const directProgress = Number(
    coin.bonding_curve_progress
      ?? coin.bondingCurveProgress
      ?? coin.graduationPercent
      ?? coin.progress
  );

  if (Number.isFinite(directProgress)) {
    return directProgress <= 1 ? directProgress * 100 : directProgress;
  }

  const reserveProgress = getPumpFunReserveProgress(coin);
  if (reserveProgress != null) return reserveProgress;

  const usdMarketCap = Number(coin.usd_market_cap ?? coin.market_cap);
  const graduationMarketCap = Number(coin.king_of_the_hill_market_cap ?? coin.raydium_migration_market_cap ?? 69000);

  if (Number.isFinite(usdMarketCap) && Number.isFinite(graduationMarketCap) && graduationMarketCap > 0) {
    return Math.min(100, (usdMarketCap / graduationMarketCap) * 100);
  }

  return null;
}

function getPumpFunReserveProgress(coin) {
  const realTokenReserves = Number(coin.real_token_reserves ?? coin.realTokenReserves);
  const initialRealTokenReserves = Number(
    coin.initial_real_token_reserves
      ?? coin.initialRealTokenReserves
  );

  if (
    Number.isFinite(realTokenReserves)
    && Number.isFinite(initialRealTokenReserves)
    && initialRealTokenReserves > 0
  ) {
    return Math.max(0, Math.min(100, ((initialRealTokenReserves - realTokenReserves) / initialRealTokenReserves) * 100));
  }

  const realSolReserves = Number(coin.real_sol_reserves ?? coin.realSolReserves);

  if (Number.isFinite(realSolReserves) && realSolReserves > 0) {
    const estimatedCompletionLamports = 85 * 1_000_000_000;
    return Math.max(0, Math.min(100, (realSolReserves / estimatedCompletionLamports) * 100));
  }

  return null;
}

async function getHeliusAssetMetadata(contract) {
  if (!HELIUS_API_KEY) return null;

  try {
    const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${HELIUS_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 'get-asset',
        method: 'getAsset',
        params: { id: contract }
      })
    });
    const body = await response.json();
    const asset = body.result;

    return {
      source: 'helius',
      name: asset?.content?.metadata?.name,
      symbol: asset?.content?.metadata?.symbol,
      imageUrl: asset?.content?.links?.image
    };
  } catch (error) {
    console.error(`Could not fetch Helius asset metadata for ${contract}:`, error.message);
    return null;
  }
}

async function getSolBalance(wallet) {
  try {
    const response = await fetch(SOLANA_RPC_HTTP, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'getBalance',
        params: [wallet]
      })
    });
    const body = await response.json();
    const lamports = body.result?.value;
    return typeof lamports === 'number' ? lamports / 1_000_000_000 : undefined;
  } catch (error) {
    console.error(`Could not fetch SOL balance for ${wallet}:`, error.message);
    return undefined;
  }
}

async function ensureHeliusTracksContract(contract) {
  if (!contract) {
    return { ok: false, skipped: true, message: 'No contract provided.' };
  }

  return ensureHeliusTracksContracts([contract]);
}

async function ensureHeliusTracksContracts(contracts) {
  const uniqueContracts = Array.from(new Set(
    contracts
      .map((contract) => String(contract ?? '').trim())
      .filter(Boolean)
  ));

  if (uniqueContracts.length === 0) {
    return { ok: false, skipped: true, message: 'No contracts to sync.' };
  }

  if (!HELIUS_API_KEY || !HELIUS_WEBHOOK_ID) {
    return {
      ok: false,
      skipped: true,
      message: 'Helius auto-sync skipped. Set HELIUS_API_KEY and HELIUS_WEBHOOK_ID on Render.'
    };
  }

  try {
    const webhook = await fetchHeliusWebhook();
    const currentAddresses = webhook.accountAddresses ?? [];
    const nextAddresses = Array.from(new Set([...currentAddresses, ...uniqueContracts]));
    const added = nextAddresses.length - currentAddresses.length;

    if (added === 0) {
      return { ok: true, added: 0, total: nextAddresses.length, message: 'Helius already tracks this CA.' };
    }

    await updateHeliusWebhook({
      ...webhook,
      accountAddresses: nextAddresses
    });

    return {
      ok: true,
      added,
      total: nextAddresses.length,
      message: `Helius synced ${added} new CA${added === 1 ? '' : 's'}.`
    };
  } catch (error) {
    console.error('Helius auto-sync failed:', error);
    return {
      ok: false,
      message: `Helius auto-sync failed: ${error.message}`
    };
  }
}

async function fetchHeliusWebhook() {
  const response = await fetch(`https://api-mainnet.helius-rpc.com/v0/webhooks/${HELIUS_WEBHOOK_ID}?api-key=${HELIUS_API_KEY}`);
  const body = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(body.error ?? body.message ?? `Helius GET failed with ${response.status}`);
  }

  return body;
}

async function updateHeliusWebhook(webhook) {
  const response = await fetch(`https://api-mainnet.helius-rpc.com/v0/webhooks/${HELIUS_WEBHOOK_ID}?api-key=${HELIUS_API_KEY}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      webhookURL: webhook.webhookURL,
      transactionTypes: webhook.transactionTypes?.length ? webhook.transactionTypes : ['ANY'],
      accountAddresses: webhook.accountAddresses ?? [],
      webhookType: webhook.webhookType ?? 'enhanced',
      authHeader: webhook.authHeader,
      encoding: webhook.encoding,
      txnStatus: webhook.txnStatus
    })
  });
  const body = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(body.error ?? body.message ?? `Helius PUT failed with ${response.status}`);
  }

  return body;
}

function renderHeliusSyncStatus(result) {
  if (!result) return '';
  if (result.ok) return result.message;
  return result.message ? `Warning: ${result.message}` : '';
}

function isValidHeliusAuth(authHeader) {
  if (!HELIUS_AUTH_HEADER) return true;
  return authHeader === HELIUS_AUTH_HEADER || authHeader === `Bearer ${HELIUS_AUTH_HEADER}`;
}

async function saveLastHeliusPayload(payload) {
  try {
    await fs.mkdir(path.resolve('data'), { recursive: true });
    await fs.writeFile(
      path.resolve('data', 'last-helius-payload.json'),
      `${JSON.stringify({ receivedAt: new Date().toISOString(), payload }, null, 2)}\n`,
      'utf8'
    );
    console.log('Received Helius webhook payload.');
  } catch (error) {
    console.error('Could not save Helius debug payload:', error.message);
  }
}
